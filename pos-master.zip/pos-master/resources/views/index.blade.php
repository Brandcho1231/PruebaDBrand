@extends("layouts/main")
@section("main")

<div class="container">
    <div class="col-12 text-center">
        <h3>Punto de venta</h3>
    </div>
</div>

@endsection

